from pyannote.core import Segment, Timeline  # type: ignore

from .merge_segments import merge_segments


def test_merge_segments():
    # Создаем тестовые данные
    timeline = Timeline()

    # Добавляем сегменты для SPEAKER_01
    timeline.add(Segment(0.030, 0.925))
    timeline.add(Segment(1.144, 2.916))
    timeline.add(Segment(3.304, 4.080))
    timeline.add(Segment(4.806, 9.970))
    timeline.add(Segment(10.577, 18.677))
    timeline.add(Segment(18.897, 21.917))
    timeline.add(Segment(22.829, 23.453))
    timeline.add(Segment(24.246, 31.418))

    # Добавляем сегменты для SPEAKER_00
    timeline.add(Segment(34.506, 36.936))
    timeline.add(Segment(37.493, 37.999))
    timeline.add(Segment(38.067, 39.147))
    timeline.add(Segment(39.906, 41.324))
    timeline.add(Segment(41.644, 42.876))
    timeline.add(Segment(43.281, 43.652))
    timeline.add(Segment(46.116, 49.305))
    timeline.add(Segment(49.896, 51.432))
    timeline.add(Segment(52.242, 56.275))
    timeline.add(Segment(56.984, 58.249))
    timeline.add(Segment(58.452, 59.245))
    timeline.add(Segment(60.460, 60.983))

    # Создаем объект с метками говорящих
    class MockDiarization:
        def itertracks(self, yield_label=True):
            print(yield_label)
            for segment in timeline:  # type: ignore
                if segment.start < 34.506:
                    yield segment, None, "SPEAKER_01"
                else:
                    yield segment, None, "SPEAKER_00"

    # Вызываем функцию
    result = merge_segments(MockDiarization())

    # Проверяем результаты
    assert len(result) == 2

    # Проверяем первый сегмент (SPEAKER_01)
    assert result[0].start == 0.030
    assert result[0].end == 31.418
    assert result[0].speaker == "SPEAKER_01"

    # Проверяем второй сегмент (SPEAKER_00)
    assert result[1].start == 34.506
    assert result[1].end == 60.983
    assert result[1].speaker == "SPEAKER_00"
