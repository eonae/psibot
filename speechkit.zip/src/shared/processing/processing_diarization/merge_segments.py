from datetime import timedelta
from typing import Any, List

from src.shared.logging import log_time
from src.shared.processing.models import DiarizationSegment, SegmentCollection


@log_time
def merge_segments(diarization: Any) -> SegmentCollection[DiarizationSegment]:
    """Объединяет идущие подряд сегменты, принадлежащие одному спикеру"""

    merged: List[DiarizationSegment] = []
    current_speaker: str | None = None
    current_start: float | None = None
    current_end: float | None = None

    def append_segment():
        assert (
            current_start is not None
            and current_end is not None
            and current_speaker is not None
        )
        merged.append(
            DiarizationSegment(
                start=timedelta(seconds=current_start),
                end=timedelta(seconds=current_end),
                speaker=current_speaker,
            )
        )

    for segment, _, speaker in diarization.itertracks(yield_label=True):
        if not current_speaker:
            current_speaker = speaker
            current_start = segment.start
            current_end = segment.end
            continue

        if speaker != current_speaker:
            append_segment()
            current_speaker = speaker
            current_start = segment.start
            current_end = segment.end
            continue

        current_end = segment.end

    append_segment()
    return SegmentCollection(merged)
