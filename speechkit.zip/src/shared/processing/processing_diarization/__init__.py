"""Пакет для работы с моделями на Hugging Face"""

from .diarize import diarize

__all__ = ["diarize"]
