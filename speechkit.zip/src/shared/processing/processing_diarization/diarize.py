import logging
from pathlib import Path

from src.app.config import Config
from src.shared.hugging_face import create_pipeline
from src.shared.logging import log_time
from src.shared.processing.models import DiarizationSegment, SegmentCollection

from .merge_segments import merge_segments

logger = logging.getLogger(__name__)


@log_time
def diarize(audio_file: Path, config: Config) -> SegmentCollection[DiarizationSegment]:
    pipeline = create_pipeline(
        "pyannote/speaker-diarization-3.1", config.HUGGING_FACE_TOKEN
    )

    logger.info("⏳ Starting diarization of %s...", audio_file)
    diarization = pipeline(audio_file, num_speakers=2)
    logger.info("✅ Diarization is completed")

    return merge_segments(diarization)
