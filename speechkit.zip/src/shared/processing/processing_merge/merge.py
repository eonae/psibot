from src.shared.logging import log_time
from src.shared.processing.models import (
    DiarizationSegment,
    RecognitionSegment,
    RecognitionSegmentWithSpeaker,
    SegmentCollection,
)


@log_time
def merge(
    recognition: SegmentCollection[RecognitionSegment],
    diarization: SegmentCollection[DiarizationSegment],
) -> SegmentCollection[RecognitionSegmentWithSpeaker]:
    """Объединяет результаты распознавания и диаризации"""
    merged: SegmentCollection[RecognitionSegmentWithSpeaker] = SegmentCollection()

    for r in recognition:
        to_append = None
        for d in diarization:
            if r.start > d.end:
                continue
            if r.end < d.start:
                continue
            to_append = r.with_speaker(d.speaker)
            break

        if to_append:
            merged.append(to_append)
        else:
            raise ValueError(f"Не удалось найти подходящий сегмент диаризации для {r}")

    return merged
