from typing import List

from src.shared.processing.models import (
    RecognitionSegmentWithSpeaker,
    SegmentCollection,
)


def split_into_chunks(
    results: SegmentCollection[RecognitionSegmentWithSpeaker], max_chars: int
) -> List[SegmentCollection[RecognitionSegmentWithSpeaker]]:
    """Split recognition results into chunks with a limit on the number of characters."""
    chunks: List[SegmentCollection[RecognitionSegmentWithSpeaker]] = []
    current_chunk: SegmentCollection[RecognitionSegmentWithSpeaker] = (
        SegmentCollection()
    )
    current_chars = 0

    for segment in results:
        # Учитываем все переносы строк в тексте
        segment_str = str(segment).replace("\n", "\\n")
        if current_chars + len(segment_str) > max_chars and current_chunk:
            chunks.append(current_chunk)
            current_chunk = SegmentCollection()
            current_chars = 0

        current_chunk.append(segment)
        current_chars += len(segment_str)

    if current_chunk:
        chunks.append(current_chunk)

    return chunks
