"""Модуль для распознавания речи"""

from .recognize import recognize

__all__ = ["recognize"]
