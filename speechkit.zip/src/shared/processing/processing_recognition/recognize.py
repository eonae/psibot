import logging
from datetime import datetime
from pathlib import Path
from time import sleep

from src.app.config import Config
from src.shared.logging import log_time
from src.shared.processing.models import RecognitionSegment, SegmentCollection
from src.shared.s3 import S3Bucket

from .parse_results import parse_recognition_result
from .speech_kit_http import SpeechKitApi

logger = logging.getLogger(__name__)


POLLING_INTERVAL = 5


@log_time
def recognize(
    audio_file: Path, config: Config
) -> SegmentCollection[RecognitionSegment]:
    """Распознавание текста из аудио файла"""

    storage = S3Bucket("speech-kit-wav", config)

    key = f"{audio_file}_{datetime.now()}"
    logger.info("🔼 Uploading file to storage: %s (key: %s)", audio_file, key)

    storage.upload_to_storage(audio_file, key)

    url = storage.get_presigned_url(key)

    logger.info("🔗 File is uploaded to storage. Presigned URL: %s", url)

    api = SpeechKitApi(config.YC_API_KEY)
    logger.info("🌎 Sending recognition request to Yandex SpeechKit")
    operation_id = api.recognize_file_async(url)
    logger.info("⏳ Operation created: %s", operation_id)

    while True:
        done = api.get_operation_status(operation_id)
        if done:
            logger.info("✅ Operation completed: %s", operation_id)
            break

        logger.info("⏳ Waiting for operation result: %s", operation_id)
        sleep(POLLING_INTERVAL)  # Ждем 5 секунд перед следующей проверкой

    logger.info("📦 Fetching recognition result: %s", operation_id)
    raw = api.get_recognition(operation_id)

    return parse_recognition_result(raw)
