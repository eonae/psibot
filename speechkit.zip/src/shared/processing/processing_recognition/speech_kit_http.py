import json
import logging
from typing import Any

import requests  # type: ignore

logger = logging.getLogger(__name__)

STT_BASE_URL = "https://stt.api.cloud.yandex.net/stt/v3"
OPERATIONS_BASE_URL = "https://operation.api.cloud.yandex.net/operations"


class SpeechKitApi:
    def __init__(self, api_key: str):
        self.headers = {
            "Authorization": f"Api-Key {api_key}",
            "Content-Type": "application/json",
        }

    # https://yandex.cloud/ru/docs/speechkit/stt-v3/api-ref/AsyncRecognizer/recognizeFile
    # Честно говоря, я не уверен, что параметры работают
    def recognize_file_async(self, s3_url: str) -> str:
        url = f"{STT_BASE_URL}/recognizeFileAsync"
        data = {
            "uri": s3_url,
            "recognition_model": {
                "model": "general",
                "audio_processing_type": "FULL_DATA",
                "audio_format": {
                    "container_audio": {
                        "container_audio_type": "WAV",
                    },
                },
                "language_restriction": {
                    "restriction_type": "WHITELIST",
                    "language_codes": ["en-EN"],
                },
            },
            "speaker_labeling": {
                "speaker_labeling": "SPEAKER_LABELING_ENABLED",
            },
        }

        response = requests.post(url, headers=self.headers, json=data, timeout=10)
        response.raise_for_status()
        operation_id = response.json()["id"]

        return operation_id

    def get_operation_status(self, operation_id: str) -> bool:
        url = f"{OPERATIONS_BASE_URL}/{operation_id}"

        response = requests.get(url, headers=self.headers, timeout=10)
        response.raise_for_status()
        return response.json()["done"]

    def get_recognition(self, operation_id: str) -> Any:
        url = f"{STT_BASE_URL}/getRecognition"
        params = {"operation_id": operation_id}

        response = requests.get(
            url, headers=self.headers, params=params, timeout=10, stream=True
        )
        response.raise_for_status()

        results = []
        for line in response.iter_lines():
            if line:
                try:
                    result = json.loads(line)
                    if "result" in result and "final" in result["result"]:
                        results.append(result)
                except json.JSONDecodeError as e:
                    logger.warning("Failed to parse JSON: %s", e)
                    continue

        return results
