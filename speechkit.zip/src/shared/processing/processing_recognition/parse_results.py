from datetime import timedelta

from src.shared.processing.models import RecognitionSegment, SegmentCollection


def parse_recognition_result(raw: list) -> SegmentCollection[RecognitionSegment]:
    """Преобразует JSON-результат в список RecognitionResult"""
    parsed: SegmentCollection[RecognitionSegment] = SegmentCollection()

    for chunk in raw:
        if "result" not in chunk or "final" not in chunk["result"]:
            continue

        final = chunk["result"]["final"]
        if "alternatives" not in final:
            continue

        for alternative in final["alternatives"]:
            if not all(
                key in alternative for key in ["text", "startTimeMs", "endTimeMs"]
            ):
                continue

            if not alternative["text"]:
                continue

            # Конвертируем миллисекунды в секунды
            start_time = timedelta(milliseconds=float(alternative["startTimeMs"]))
            end_time = timedelta(milliseconds=float(alternative["endTimeMs"]))

            # Получаем speaker, если он есть
            speaker = alternative.get("speaker", None)

            # Создаем результат распознавания
            result = RecognitionSegment(
                start_time, end_time, alternative["text"], speaker
            )
            print(result)
            parsed.append(result)

    return parsed
