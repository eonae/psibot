from datetime import timedelta

from .segment_base import Segment


class RecognitionSegmentWithSpeaker(Segment):
    """Результат распознавания с указанием спикера"""

    speaker: str

    def __init__(self, start: timedelta, end: timedelta, speaker: str, text: str):
        super().__init__(start=start, end=end, speaker=speaker, text=text)

    @classmethod
    def from_segment(cls, segment: Segment) -> "RecognitionSegmentWithSpeaker":
        if not segment.text:
            raise ValueError("Text is required in RecognitionResult")

        if not segment.speaker:
            raise ValueError("Speaker is required in RecognitionResultWithSpeaker")

        return RecognitionSegmentWithSpeaker(
            start=segment.start,
            end=segment.end,
            text=segment.text,
            speaker=segment.speaker,
        )
