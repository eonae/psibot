"""Модель данных для результатов распознавания, диаризации и т. д."""

from .segment_base import Segment
from .segment_collection import SegmentCollection
from .segment_diarization import DiarizationSegment
from .segment_recognition import RecognitionSegment
from .segment_recognition_with_speaker import RecognitionSegmentWithSpeaker
