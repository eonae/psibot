from datetime import timedelta

from .segment_base import Segment
from .segment_recognition_with_speaker import RecognitionSegmentWithSpeaker


class RecognitionSegment(Segment):
    text: str

    """Результат распознавания"""

    def __init__(
        self, start: timedelta, end: timedelta, text: str, speaker: str | None = None
    ):
        super().__init__(start=start, end=end, speaker=speaker, text=text)

    def with_speaker(self, speaker: str) -> RecognitionSegmentWithSpeaker:
        return RecognitionSegmentWithSpeaker(
            start=self.start, end=self.end, speaker=speaker, text=self.text
        )

    @classmethod
    def from_segment(cls, segment: Segment) -> "RecognitionSegment":
        if not segment.text:
            raise ValueError("Text is required in RecognitionResult")

        return RecognitionSegment(
            start=segment.start,
            end=segment.end,
            text=segment.text,
            speaker=segment.speaker,
        )
