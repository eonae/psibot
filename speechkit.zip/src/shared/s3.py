import os
from pathlib import Path
from typing import Optional

import boto3  # type: ignore

from src.app.config import Config  # type: ignore


class S3Bucket:
    def __init__(self, bucket_name: str, config: Config):
        self.bucket_name = bucket_name
        self.s3_client = boto3.client(
            "s3",
            endpoint_url=config.YC_S3_ENDPOINT,
            aws_access_key_id=config.YC_ACCESS_KEY_ID,
            aws_secret_access_key=config.YC_SECRET_ACCESS_KEY,
        )

    def upload_to_storage(
        self, path: str | Path, object_name: Optional[str] = None
    ) -> None:
        if object_name is None:
            object_name = os.path.basename(path)

        return self.s3_client.upload_file(path, self.bucket_name, object_name)

    def get_presigned_url(self, object_name: str | Path) -> str:
        return self.s3_client.generate_presigned_url(
            "get_object",
            Params={"Bucket": self.bucket_name, "Key": str(object_name)},
            ExpiresIn=3600,
        )
