from src.app.adapters.celery.app import app

__all__ = ["app"]
