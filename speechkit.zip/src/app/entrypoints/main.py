import asyncio
import logging

from aiogram import Dispatcher  # type: ignore

from src.app.adapters.celery import celery_results
from src.app.adapters.telegram.bot import bot
from src.app.adapters.telegram.handlers import router
from src.shared.logging import setup_logging

logger = logging.getLogger(__name__)


async def main() -> None:
    # Настраиваем логирование
    setup_logging(level=logging.DEBUG)

    # Проверяем токен бота
    logger.info("Checking bot token...")
    if not bot.token:
        logger.error("Bot token is not set!")
        return

    # Создаем диспетчер
    dp = Dispatcher()
    dp.include_router(router)

    # Запускаем celery_results в фоновом режиме
    celery_task = asyncio.create_task(celery_results.start())

    try:
        # Запускаем бота
        logger.info("Starting bot...")
        await dp.start_polling(bot)
    finally:
        # Останавливаем celery_results при завершении
        await celery_results.stop()
        celery_task.cancel()
        try:
            await celery_task
        except asyncio.CancelledError:
            pass


if __name__ == "__main__":
    asyncio.run(main())
