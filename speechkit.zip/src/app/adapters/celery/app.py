import asyncio

from celery import Celery, Task  # type: ignore
from celery.signals import task_failure, task_success  # type: ignore
from redis.asyncio import Redis  # type: ignore

from lib.celery_reactive import ReactiveResults  # type: ignore
from src.app.config import Config

config = Config()
redis = Redis.from_url(config.CELERY_BROKER_URL)
results = ReactiveResults(redis)

app = Celery(
    "speechkit",
    broker=config.CELERY_BROKER_URL,
    backend=config.CELERY_RESULT_BACKEND,
    include=["src.app.adapters.celery.tasks"],
)

app.conf.update(
    task_serializer="json",
    accept_content=["json"],
    result_serializer="json",
    timezone="Europe/Moscow",
    enable_utc=True,
    task_track_started=True,
    task_publish_retry=True,
    task_ignore_result=False,
    result_expires=3600,
    task_store_errors_even_if_ignored=True,
    task_store_metadata=True,
)


@task_success.connect
def notify_task_success(sender: Task, **_):
    loop = asyncio.get_event_loop()
    if loop.is_running():
        loop.create_task(results.publish(sender))
    else:
        loop.run_until_complete(results.publish(sender))


@task_failure.connect
def notify_task_failure(sender: Task, **_):
    loop = asyncio.get_event_loop()
    if loop.is_running():
        loop.create_task(results.publish(sender))
    else:
        loop.run_until_complete(results.publish(sender))
