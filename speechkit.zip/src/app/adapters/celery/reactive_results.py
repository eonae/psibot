from redis.asyncio import Redis  # type: ignore

from lib.celery_reactive.reactive_results import ReactiveResults
from src.app.config import Config

from .handlers.handle_convert_result import handle_convert_result
from .handlers.handle_diarization_result import handle_diarization_result
from .handlers.handle_download_result import handle_download_result
from .handlers.handle_merge_result import handle_merge_result
from .handlers.handle_postprocessing_result import handle_postprocessing_result
from .handlers.handle_transcribing_result import handle_transcribing_result
from .tasks import (
    convert_to_wav_task,
    diarize_audio_task,
    download_audio_task,
    merge_results_task,
    postprocess_results_task,
    transcribe_audio_task,
)

config = Config()

redis = Redis.from_url(config.CELERY_BROKER_URL)
celery_results = ReactiveResults(redis)

celery_results.subscribe(download_audio_task.name, handle_download_result)
celery_results.subscribe(convert_to_wav_task.name, handle_convert_result)
celery_results.subscribe(diarize_audio_task.name, handle_diarization_result)
celery_results.subscribe(transcribe_audio_task.name, handle_transcribing_result)
celery_results.subscribe(merge_results_task.name, handle_merge_result)
celery_results.subscribe(postprocess_results_task.name, handle_postprocessing_result)
