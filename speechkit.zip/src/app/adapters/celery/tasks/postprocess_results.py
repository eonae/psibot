import logging
from pathlib import Path

from src.app.adapters.celery.app import app
from src.app.adapters.files import storage
from src.app.config import Config
from src.shared.processing import transform
from src.shared.processing.models import (
    RecognitionSegmentWithSpeaker,
    SegmentCollection,
)

logger = logging.getLogger(__name__)


@app.task
def postprocess_results_task(source_filename: str, target_filename: str) -> None:
    """Пост-обработка результатов распознавания

    Args:
        source_filename: Путь к файлу с объединенными результатами
        target_filename: Путь для сохранения результата
    """
    logger.info("🎯 Starting post-processing of %s...", source_filename)

    # Загружаем объединенные результаты
    text_data = storage.read(Path(source_filename)).decode()
    parsed_data = SegmentCollection.parse(text_data, RecognitionSegmentWithSpeaker)

    # Выполняем пост-обработку
    config = Config()
    transformed_results = transform(parsed_data, config)

    # Сохраняем результат
    storage.save(str(transformed_results).encode(), Path(target_filename))

    logger.info("✅ Post-processing completed: %s", target_filename)
