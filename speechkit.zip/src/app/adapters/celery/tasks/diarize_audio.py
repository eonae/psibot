import logging
import tempfile
from pathlib import Path

from src.app.adapters.celery.app import app
from src.app.adapters.files import storage
from src.app.config import Config
from src.shared.processing import diarize

logger = logging.getLogger(__name__)


@app.task
def diarize_audio_task(wav_filename: str, target_filename: str) -> None:
    """Диаризация аудио файла

    Args:
        wav_filename: Путь к WAV файлу
        target_filename: Путь для сохранения результата
    """
    logger.info("🎯 Starting diarization of %s...", target_filename)

    # Читаем файл из хранилища
    audio_data = storage.read(Path(wav_filename))

    with tempfile.NamedTemporaryFile(suffix=".wav", delete=True) as tmp:
        tmp.write(audio_data)
        tmp.flush()  # обязательно, чтобы всё записалось на диск

        tmp_path = Path(tmp.name)

        config = Config()
        diarization_result = diarize(tmp_path, config)

        storage.save(str(diarization_result).encode(), Path(target_filename))

        logger.info("✅ Diarization completed: %s", target_filename)
