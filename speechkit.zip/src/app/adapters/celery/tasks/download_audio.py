import logging
from pathlib import Path

import requests  # type: ignore

from src.app.adapters.celery.app import app
from src.app.adapters.files import storage
from src.app.config import Config

# Здесь нам нужен бот только для скачивания файла.
# В принципе можно было бы и через HTTP

config = Config()

BOT = f"bot{config.TELEGRAM_BOT_TOKEN}"
TELEGRAM_BASE_URL = "https://api.telegram.org"

logger = logging.getLogger(__name__)


@app.task
def download_audio_task(file_id: str, target_filename: str) -> None:
    """Скачивает аудиофайл из Telegram

    Args:
        file_id: ID файла в Telegram
        target_filename: Имя файла для сохранения
    """

    # Получаем информацию о файле
    url = f"{TELEGRAM_BASE_URL}/{BOT}/getFile"
    response = requests.get(url, params={"file_id": file_id}, timeout=10)
    response.raise_for_status()
    path = response.json()["result"]["file_path"]

    # Скачиваем файл
    url = f"{TELEGRAM_BASE_URL}/file/{BOT}/{path}"
    response = requests.get(url, timeout=10)
    response.raise_for_status()

    # Сохраняем файл через хранилище
    storage.save(response.content, Path(target_filename))
    logger.info("✅ Audio file downloaded and saved: %s", target_filename)
