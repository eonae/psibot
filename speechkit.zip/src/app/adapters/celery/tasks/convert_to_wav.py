import logging
from io import BytesIO
from pathlib import Path

import librosa
import soundfile as sf  # type: ignore

from src.app.adapters.celery.app import app
from src.app.adapters.files import storage

logger = logging.getLogger(__name__)

# Частота дискретизации для WAV файлов
SAMPLE_RATE = 16000


@app.task
def convert_to_wav_task(source_filename: str, target_filename: str) -> None:
    """Конвертирует аудиофайл в WAV (если он уже WAV - просто копируем)

    Args:
        source_filename: Путь к исходному аудиофайлу
        target_filename: Путь для сохранения WAV файла
    """
    # Если исходный файл уже WAV - просто копируем
    if source_filename.lower().endswith(".wav"):
        logger.info("📋 Source file is already WAV, copying to %s", target_filename)
        storage.copy(Path(source_filename), Path(target_filename))
        return

    logger.info("🔄 Converting %s to WAV...", source_filename)

    # Читаем исходный файл
    audio_data = storage.read(Path(source_filename))

    # Загружаем аудио из байтов через BytesIO
    # y - numpy массив с аудио данными (амплитуда звука)
    # sr - частота дискретизации (количество сэмплов в секунду)
    y, sr = librosa.load(BytesIO(audio_data), sr=SAMPLE_RATE)

    # Сохраняем в WAV используя soundfile (sf)
    # sf.write сохраняет аудио данные в файл с указанной частотой дискретизации
    sf.write(target_filename, y, sr)
    logger.info("✅ Conversion completed: %s", target_filename)
