import logging
import tempfile
from pathlib import Path

from src.app.adapters.celery.app import app
from src.app.adapters.files import storage
from src.app.config import Config
from src.shared.processing import recognize

logger = logging.getLogger(__name__)


@app.task
def transcribe_audio_task(wav_filename: str, target_filename: str) -> None:
    """Транскрибация аудио файла

    Args:
        wav_filename: Путь к WAV файлу
        target_filename: Путь для сохранения результата
    """
    logger.info("🎯 Starting transcription of %s...", wav_filename)

    # Читаем файл из хранилища
    audio_data = storage.read(Path(wav_filename))

    with tempfile.NamedTemporaryFile(suffix=".wav", delete=True) as tmp:
        tmp.write(audio_data)
        tmp.flush()  # обязательно, чтобы всё записалось на диск

        tmp_path = Path(tmp.name)

        config = Config()
        recognition_result = recognize(tmp_path, config)

        # Сохраняем результат
        storage.save(str(recognition_result).encode(), Path(target_filename))

        logger.info("✅ Transcription completed: %s", target_filename)
