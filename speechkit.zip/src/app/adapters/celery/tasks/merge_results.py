import logging
from pathlib import Path

from src.app.adapters.celery.app import app
from src.app.adapters.files import storage
from src.shared.processing import merge
from src.shared.processing.models import (
    DiarizationSegment,
    RecognitionSegment,
    SegmentCollection,
)

logger = logging.getLogger(__name__)


@app.task
def merge_results_task(
    diarization_filename: str,
    recognition_filename: str,
    target_filename: str,
) -> None:
    """Объединение результатов диаризации и транскрибации

    Args:
        diarization_filename: Путь к файлу с диаризацией
        recognition_filename: Путь к файлу с транскрибацией
        target_filename: Путь для сохранения результата
    """
    logger.info("🎯 Starting merging results for %s...", target_filename)

    # Загружаем результаты диаризации
    diarization_data = storage.read(Path(diarization_filename))
    diarization = SegmentCollection.parse(diarization_data.decode(), DiarizationSegment)

    # Загружаем результаты транскрибации
    recognition_data = storage.read(Path(recognition_filename))
    recognition = SegmentCollection.parse(recognition_data.decode(), RecognitionSegment)

    # Объединяем результаты
    merged_results = merge(recognition, diarization)

    # Сохраняем результат
    storage.save(str(merged_results).encode(), Path(target_filename))

    logger.info("✅ Merging completed: %s", target_filename)
