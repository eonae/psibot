from typing import Any
from uuid import UUID

from lib.celery_reactive.reactive_results import Headers
from src.app.adapters.celery import CeleryScheduler
from src.app.adapters.db import jobs_repository
from src.app.adapters.telegram import TelegramNotifier
from src.app.adapters.telegram.bot import bot
from src.app.core.use_cases import HandleDiarizationResultUseCase


async def handle_diarization_result(
    ex: Exception | None, _: Any | None, headers: Headers
):
    """Обработчик успешного завершения диаризации аудио"""
    job_id = headers.get("job_id")
    assert job_id is not None

    notifier = TelegramNotifier(bot)

    use_case = HandleDiarizationResultUseCase(
        jobs_repository=jobs_repository,
        notifier=notifier,
        tasks_scheduler=CeleryScheduler(),
    )

    await use_case.execute(UUID(job_id), ex)
