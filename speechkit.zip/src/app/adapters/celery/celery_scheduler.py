from uuid import UUID

from lib.celery_reactive import Headers
from src.app.core.ports import TasksScheduler

from .tasks import (
    convert_to_wav_task,
    diarize_audio_task,
    download_audio_task,
    merge_results_task,
    postprocess_results_task,
    transcribe_audio_task,
)


class CeleryScheduler(TasksScheduler):
    def schedule_download_audio(
        self, job_id: UUID, file_id: str, target_filename: str
    ) -> None:
        download_audio_task.apply_async(
            args=[file_id, target_filename],
            headers=self._get_headers(job_id),
        )

    def schedule_convert_audio(
        self, job_id: UUID, source_filename: str, target_filename: str
    ) -> None:
        convert_to_wav_task.apply_async(
            args=[source_filename, target_filename],
            headers=self._get_headers(job_id),
        )

    def schedule_diarize_audio(
        self, job_id: UUID, wav_filename: str, target_filename: str
    ) -> None:
        diarize_audio_task.apply_async(
            args=[wav_filename, target_filename],
            headers=self._get_headers(job_id),
        )

    def schedule_transcribe_audio(
        self, job_id: UUID, wav_filename: str, target_filename: str
    ) -> None:
        transcribe_audio_task.apply_async(
            args=[wav_filename, target_filename],
            headers=self._get_headers(job_id),
        )

    def schedule_merge_results(
        self,
        job_id: UUID,
        diarization_filename: str,
        recognition_filename: str,
        target_filename: str,
    ) -> None:
        merge_results_task.apply_async(
            args=[diarization_filename, recognition_filename, target_filename],
            headers=self._get_headers(job_id),
        )

    def schedule_postprocess_results(
        self, job_id: UUID, source_filename: str, target_filename: str
    ) -> None:
        postprocess_results_task.apply_async(
            args=[source_filename, target_filename],
            headers=self._get_headers(job_id),
        )

    def _get_headers(self, job_id: UUID) -> Headers:
        return {"job_id": str(job_id)}
