from .di import storage
from .local_file_storage import LocalFileStorage

__all__ = ["storage", "LocalFileStorage"]
