from .di import jobs_repository

__all__ = ["jobs_repository"]
