from .jobs_repository import InMemoryJobsRepository

jobs_repository = InMemoryJobsRepository()
