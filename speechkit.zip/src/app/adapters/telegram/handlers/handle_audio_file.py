from aiogram.types import Message, Voice  # type: ignore

from src.app.adapters.celery import CeleryScheduler
from src.app.adapters.db import jobs_repository
from src.app.adapters.telegram import TelegramResponder
from src.app.adapters.telegram.bot import bot
from src.app.core.models import InputFileDTO
from src.app.core.use_cases import HandleNewFileUseCase


async def handle_audio_file(message: Message) -> None:
    """Обработчик аудиофайла"""

    file = message.audio or message.document or message.voice
    if not file:
        return

    # Создаем use case
    use_case = HandleNewFileUseCase(
        jobs=jobs_repository,
        responder=TelegramResponder(message, bot),
        tasks_scheduler=CeleryScheduler(),
    )

    # Выполняем use case
    await use_case.execute(
        message.chat.id,
        InputFileDTO(
            file_id=file.file_id,
            mime_type=file.mime_type,
            size=file.file_size,
            filename=(file.file_name if not isinstance(file, Voice) else None),
        ),
    )
