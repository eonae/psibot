from typing import Protocol
from uuid import UUID


class TasksScheduler(Protocol):
    def schedule_download_audio(
        self, job_id: UUID, file_id: str, target_filename: str
    ) -> None:
        ...

    def schedule_convert_audio(
        self, job_id: UUID, source_filename: str, target_filename: str
    ) -> None:
        ...

    def schedule_diarize_audio(
        self, job_id: UUID, wav_filename: str, target_filename: str
    ) -> None:
        ...

    def schedule_transcribe_audio(
        self, job_id: UUID, wav_filename: str, target_filename: str
    ) -> None:
        ...

    def schedule_merge_results(
        self,
        job_id: UUID,
        diarization_filename: str,
        recognition_filename: str,
        target_filename: str,
    ) -> None:
        ...

    def schedule_postprocess_results(
        self, job_id: UUID, source_filename: str, target_filename: str
    ) -> None:
        ...
