import logging
from uuid import UUID

from src.app.core.models import JobStatus
from src.app.core.ports import JobsRepository, Notifier, TasksScheduler

logger = logging.getLogger(__name__)


class HandleDownloadResultUseCase:
    def __init__(
        self,
        jobs_repository: JobsRepository,
        tasks_scheduler: TasksScheduler,
        notifier: Notifier,
    ):
        self.jobs_repository = jobs_repository
        self.tasks_scheduler = tasks_scheduler
        self.notifier = notifier

    async def execute(self, job_id: UUID, error: Exception | None) -> None:
        logger.info("Handling download result for job %s", job_id)

        job = await self.jobs_repository.get_one(job_id)

        if not job:
            raise ValueError(f"Job id={job_id} not found")

        if not job.status == JobStatus.DOWNLOADING:
            raise ValueError(
                f"Job id={job_id} is incorrect status for download complete"
            )

        if error is not None:
            job.set_failed(error)
            await self.jobs_repository.save(job)
            await self.notifier.notify_download_failed(job.user_id)
            raise error

        job.to_stage(JobStatus.CONVERTING)

        self.tasks_scheduler.schedule_convert_audio(
            job_id=job.id,
            source_filename=str(job.files.wav),
            target_filename=str(job.files.diarization),
        )

        await self.jobs_repository.save(job)
        await self.notifier.notify_download_completed(job.user_id)
