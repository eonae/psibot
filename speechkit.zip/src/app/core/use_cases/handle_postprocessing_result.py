import logging
from pathlib import Path
from uuid import UUID

from src.app.core.models import JobStatus
from src.app.core.ports import FileStorage, JobsRepository, Notifier, TasksScheduler

logger = logging.getLogger(__name__)


class HandlePostprocessingResultUseCase:
    def __init__(
        self,
        jobs_repository: JobsRepository,
        tasks_scheduler: TasksScheduler,
        notifier: Notifier,
        storage: FileStorage,
    ):
        self.jobs_repository = jobs_repository
        self.tasks_scheduler = tasks_scheduler
        self.notifier = notifier
        self.storage = storage

    async def execute(self, job_id: UUID, error: Exception | None) -> None:
        logger.info("Handling postprocessing result for job %s", job_id)

        job = await self.jobs_repository.get_one(job_id)

        if not job:
            raise ValueError(f"Job id={job_id} not found")

        if not job.status == JobStatus.POSTPROCESSING:
            raise ValueError(
                f"Job id={job_id} is incorrect status for postprocessing complete"
            )

        if error is not None:
            job.set_failed(error)
            await self.jobs_repository.save(job)
            await self.notifier.notify_postprocessing_failed(job.user_id)
            raise error

        job.to_stage(JobStatus.PENDING_CONFIRMATION)
        await self.jobs_repository.save(job)

        logger.info("Sending results %s", job.files.postprocessed)
        file = self.storage.read(job.files.postprocessed)

        # Формируем имя файла с расширением .txt
        result_filename = Path(job.original_filename).with_suffix(".txt").name

        # Отправляем файл с результатом и клавиатуру подтверждения
        await self.notifier.send_result_with_confirmation(
            user_id=job.user_id,
            filename=result_filename,
            file=file,
        )
