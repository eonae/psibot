import logging
from uuid import UUID

from src.app.core.models import JobStatus
from src.app.core.ports import JobsRepository, Notifier, TasksScheduler

logger = logging.getLogger(__name__)


class HandleConvertResultUseCase:
    def __init__(
        self,
        jobs_repository: JobsRepository,
        notifier: Notifier,
        tasks_scheduler: TasksScheduler,
    ):
        self.jobs_repository = jobs_repository
        self.notifier = notifier
        self.background_tasks = tasks_scheduler

    async def execute(self, job_id: UUID, error: Exception | None) -> None:
        logger.info("Handling convert result for job %s", job_id)

        job = await self.jobs_repository.get_one(job_id)

        if not job:
            raise ValueError(f"Job id={job_id} not found")

        if not job.status == JobStatus.CONVERTING:
            raise ValueError(
                f"Job id={job_id} is incorrect status for convert complete"
            )

        if error is not None:
            job.set_failed(error)
            await self.jobs_repository.save(job)
            await self.notifier.notify_convert_failed(job.user_id)
            raise error

        job.to_stage(JobStatus.DIARIZING)

        self.background_tasks.schedule_diarize_audio(
            job_id=job.id,
            wav_filename=str(job.files.wav),
            target_filename=str(job.files.diarization),
        )

        await self.jobs_repository.save(job)
        await self.notifier.notify_convert_completed(job.user_id)
