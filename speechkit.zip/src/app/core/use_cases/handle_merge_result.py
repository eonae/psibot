import logging
from uuid import UUID

from src.app.core.models import JobStatus
from src.app.core.ports import JobsRepository, Notifier, TasksScheduler

logger = logging.getLogger(__name__)


class HandleMergeResultUseCase:
    def __init__(
        self,
        jobs_repository: JobsRepository,
        notifier: Notifier,
        tasks_scheduler: TasksScheduler,
    ):
        self.jobs_repository = jobs_repository
        self.notifier = notifier
        self.tasks_scheduler = tasks_scheduler

    async def execute(self, job_id: UUID, error: Exception | None) -> None:
        logger.info("Handling merge result for job %s", job_id)

        job = await self.jobs_repository.get_one(job_id)

        if not job:
            raise ValueError(f"Job id={job_id} not found")

        if not job.status == JobStatus.MERGING:
            raise ValueError(f"Job id={job_id} is incorrect status for merge complete")

        if error is not None:
            job.set_failed(error)
            await self.jobs_repository.save(job)
            await self.notifier.notify_merge_failed(job.user_id)
            raise error

        job.to_stage(JobStatus.POSTPROCESSING)

        self.tasks_scheduler.schedule_postprocess_results(
            job_id=job.id,
            source_filename=str(job.files.merged),
            target_filename=str(job.files.postprocessed),
        )

        await self.jobs_repository.save(job)
        await self.notifier.notify_merge_completed(job.user_id)
